#include <iostream>
#include <thread>
#include <chrono>
using namespace std;
void dwork()
{
	setlocale(LC_ALL, "ru");
	for (size_t i = 0; i < 10; i++)
	{
		cout << "id ������ = \t" << this_thread::get_id() << "\tdwork\t" << i << endl;
		this_thread::sleep_for(chrono::milliseconds(1000));
	}
}
int main()
{
	setlocale(LC_ALL, "ru");
	thread th(dwork);
	thread th2(dwork);
	
	for (size_t i = 0; i < 10; i++)
	{
		cout << "id ������ = \t" << this_thread::get_id() << "\tmain\t" << i << endl;
		this_thread::sleep_for(chrono::milliseconds(1000));
	}
	th.join();
	th2.join();
	return 0;
}